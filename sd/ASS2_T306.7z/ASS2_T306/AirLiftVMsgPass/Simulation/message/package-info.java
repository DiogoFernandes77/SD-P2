/**
 * Package Structure of the messages of communication between server and client
 */
package Simulation.message;