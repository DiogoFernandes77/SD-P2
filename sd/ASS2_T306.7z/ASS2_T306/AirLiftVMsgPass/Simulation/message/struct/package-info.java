/**
 * Package Struct for message of each class
 */
package Simulation.message.struct;