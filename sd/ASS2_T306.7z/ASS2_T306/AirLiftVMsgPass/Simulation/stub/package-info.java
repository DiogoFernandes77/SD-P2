/**
 * Package Channel of communication
 */
package Simulation.stub;