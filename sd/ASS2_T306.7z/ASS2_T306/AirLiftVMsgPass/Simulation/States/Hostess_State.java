package Simulation.States;

/**
 * Hostess Possible States
 */
public enum Hostess_State{
        WAIT_FOR_NEXT_FLIGHT,
        WAIT_FOR_PASSENGER,
        CHECK_PASSENGER,
        READY_TO_FLY
    }
