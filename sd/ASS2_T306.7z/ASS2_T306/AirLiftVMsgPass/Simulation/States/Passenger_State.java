package Simulation.States;
/**
 * Passenger Possible States
 */
public enum Passenger_State{
        GOING_TO_AIRPORT,
        IN_QUEUE,
        IN_FLIGHT,
        AT_DESTINATION
}
