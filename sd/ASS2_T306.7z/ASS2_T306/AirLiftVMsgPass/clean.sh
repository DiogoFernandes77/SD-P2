find . -type f -path "./Simulation/*/*" -name "*.class" -exec rm -f {} \;
